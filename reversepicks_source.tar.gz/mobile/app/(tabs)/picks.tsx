import React, { useState, useCallback, useRef } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity,
  ActivityIndicator, Alert, Platform, RefreshControl,
  Modal, ScrollView, Pressable,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import * as Haptics from 'expo-haptics';
import { Ionicons } from '@expo/vector-icons';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import Reanimated, {
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
  FadeInDown,
} from 'react-native-reanimated';
import SwipeablePickRow from '@/components/SwipeablePickRow';
import { router } from 'expo-router';
import Colors from '@/constants/colors';
import NotificationBell from '@/components/NotificationBell';
import { listPicks, deletePick, fetchPickAnalysis, generateMatchReview, Pick } from '@/lib/api';
import { useAuth } from '@/contexts/AuthContext';

type Tab = 'live' | 'history';
type SportKey = 'soccer' | 'mlb' | 'cs2';

const PROP_LABELS: Record<string, string> = {
  pass_attempts: 'Pass Attempts', shots: 'Shots', shots_on_target: 'SOT',
  goals: 'Goals', assists: 'Assists', key_passes: 'Key Passes',
  tackles: 'Tackles', saves: 'Saves', dribbles: 'Dribbles', crosses: 'Crosses',
  interceptions: 'Interceptions', blocks: 'Blocks', fouls_drawn: 'Fouls Drawn',
  fouls_committed: 'Fouls', clearances: 'Clearances', duels_won: 'Duels Won',
  yellow_cards: 'Yellow Cards', shots_assisted: 'Shot Assists', passes: 'Passes',
};

const MLB_PROP_SET = new Set([
  'pitcher_strikeouts', 'innings_pitched', 'hits_allowed', 'earned_runs',
  'walks_allowed', 'pitches_thrown', 'batters_faced', 'hits', 'home_runs',
  'rbi', 'walks', 'strikeouts', 'runs', 'total_bases', 'stolen_bases',
  'doubles', 'plate_appearances', 'hitter_fantasy_points',
]);

const CS2_PROP_SET = new Set([
  'maps_1_2_kills', 'maps_1_2_headshots', 'maps_1_2_deaths',
  'maps_1_2_assists', 'maps_1_2_adr', 'map3_kills', 'map3_headshots',
  'map3_deaths', 'map3_assists', 'map3_adr', 'kills', 'headshots',
  'deaths', 'adr', 'mvps', 'rating', 'headshot_pct',
]);

function getSport(p: Pick): SportKey {
  if (p.sport === 'mlb' || MLB_PROP_SET.has(p.propType)) return 'mlb';
  if (p.sport === 'cs2' || CS2_PROP_SET.has(p.propType)) return 'cs2';
  return 'soccer';
}

const SPORT_META: Record<SportKey, { label: string; icon: string }> = {
  soccer: { label: 'Soccer', icon: '⚽' },
  mlb:    { label: 'MLB',    icon: '⚾' },
  cs2:    { label: 'CS2',    icon: '🎮' },
};

function isLive(p: Pick) {
  return p.matchStatus === 'live' || p.status === 'live' || p.status === 'pending' || (!p.status && !['hit','miss','push','won','lost','dnp'].includes(p.result ?? ''));
}
function isSettled(p: Pick) {
  return p.matchStatus === 'final' || p.status === 'settled' || ['hit','miss','push','won','lost','dnp'].includes(p.result ?? '');
}
function pickWon(p: Pick) {
  return p.result === 'hit' || p.result === 'won' || p.status === 'won';
}
function pickLost(p: Pick) {
  return p.result === 'miss' || p.result === 'lost' || p.status === 'lost';
}
function pickPush(p: Pick) {
  return p.result === 'push';
}
function pickDnp(p: Pick) {
  return p.result === 'dnp';
}

function PulsingDot() {
  const opacity = useSharedValue(1);
  React.useEffect(() => {
    opacity.value = withRepeat(
      withSequence(withTiming(0.2, { duration: 700 }), withTiming(1, { duration: 700 })),
      -1, false
    );
  }, []);
  const style = useAnimatedStyle(() => ({ opacity: opacity.value }));
  return <Reanimated.View style={[{ width: 5, height: 5, borderRadius: 2.5, backgroundColor: Colors.primary }, style]} />;
}


function PickCard({ pick, onDelete }: { pick: Pick; onDelete?: () => void }) {
  const won = pickWon(pick);
  const lost = pickLost(pick);
  const live = isLive(pick);

  const push = pickPush(pick);
  const dnp = pickDnp(pick);
  const statusColor = won ? Colors.success : lost ? Colors.error : push ? Colors.push : dnp ? Colors.dnp : Colors.textTertiary;

  const propLabel = PROP_LABELS[pick.propType] || pick.propType?.replace(/_/g, ' ') || '—';
  const venueStr = pick.venue ? pick.venue.toUpperCase() : '';
  // Position/role label is only meaningful for soccer. CS2 and MLB don't have
  // tactical roles like "Box-to-Box" — those leaked in from the soccer
  // position resolver. Suppress the label entirely for non-soccer picks.
  const cardSport = getSport(pick);
  const posLabel = cardSport === 'soccer'
    ? [pick.position, pick.role].filter(Boolean).join(' · ')
    : '';

  const settled = won || lost || push;
  const nowValue = settled
    ? (pick.actualValue ?? (pick as { currentValue?: number | null }).currentValue ?? null)
    : ((pick as { currentValue?: number | null }).currentValue ?? pick.actualValue ?? null);
  const projValue = pick.projection ?? (pick as { projectedValue?: number | null }).projectedValue ?? null;
  const livePace = (pick as { pace?: number | null }).pace;
  const matchStatus = (pick as { matchStatus?: string }).matchStatus;
  const hasLiveData = matchStatus === 'live' || (livePace != null && livePace > 0) || nowValue != null;
  const paceValue = settled ? projValue : (livePace != null && livePace > 0 ? livePace : projValue);
  const hitPct = (pick as { hitPct?: number | null }).hitPct ?? (pick as { hitRate?: number | null }).hitRate ?? (pick as { winRate?: number | null }).winRate;
  const lineValue = typeof pick.line === 'number' ? pick.line : null;

  // Always show OVER or UNDER — never PASS. For historical PASS picks,
  // use the flipped direction (fade the model: lean OVER → show UNDER, lean UNDER → show OVER).
  const rec = pick.recommendation;
  const effectiveDir: 'OVER' | 'UNDER' | null =
    rec === 'OVER' ? 'OVER'
    : rec === 'UNDER' ? 'UNDER'
    : projValue != null && lineValue != null
      ? (projValue < lineValue ? 'OVER' : 'UNDER')   // flipped: fade the model's lean
      : null;
  const isOver = effectiveDir === 'OVER';
  const isUnder = effectiveDir === 'UNDER';
  const recColor = isOver ? Colors.primary : isUnder ? Colors.error : Colors.textSecondary;

  const trackValue = nowValue ?? paceValue ?? null;
  const trackDistance = lineValue != null && lineValue > 0 && trackValue != null
    ? Math.max(0, Math.min(2, trackValue / lineValue))
    : null;
  const trackFillPct = trackDistance != null
    ? Math.max(6, Math.min(94, (trackDistance / 2) * 100))
    : null;
  const trackMarkerPct = 50;
  const progressFillPct = lineValue != null && trackValue != null
    ? Math.max(0, Math.min(100, (trackValue / Math.max(lineValue * 2, 1)) * 100))
    : null;
  const trackColor = won
    ? Colors.success
    : lost
    ? Colors.error
    : push
    ? Colors.push
    : dnp
    ? Colors.dnp
    : trackValue != null && lineValue != null
    ? ((isOver && trackValue > lineValue) || (isUnder && trackValue < lineValue) ? Colors.success : Colors.error)
    : Colors.textSecondary;
  const paceColor = trackValue != null ? Colors.primary : Colors.textSecondary;

  const nowLabel = (won || lost || push) ? 'FINAL' : dnp ? 'DNP' : (hasLiveData ? 'NOW' : null);
  const paceLabel = dnp ? 'DNP' : settled ? 'PROJ' : (livePace != null && livePace > 0 ? 'PACE' : 'PROJ');

  // Determine home/away team labels.
  // PREFERRED path: backend resolved fixture → both `homeTeam` and `awayTeam` set.
  // FALLBACK path: legacy picks may only have `teamName`/`opponentName`/`venue`/`matchScore`.
  //   We orient using `venue` ('home' = subject team is home; 'away' = subject is away).
  //   If `venue` is missing/unknown we cannot trust orientation, so we hide the score line
  //   (prevents showing wrong winner color or flipping goals).
  const venueLower = (pick.venue || '').toLowerCase();
  const venueKnown = venueLower === 'home' || venueLower === 'away';
  const hasFixtureNames = !!(pick.homeTeam && pick.awayTeam);
  const homeTeamName = pick.homeTeam
    || (venueKnown ? (venueLower === 'away' ? pick.opponentName : pick.teamName) : '')
    || '';
  const awayTeamName = pick.awayTeam
    || (venueKnown ? (venueLower === 'away' ? pick.teamName : pick.opponentName) : '')
    || '';
  // Resolve final goals — prefer explicit fields, otherwise parse legacy `matchScore` string.
  // Note: `matchScore` is stored player-perspective ("subject_goals-opp_goals"), NOT home-away.
  // We can only re-orient correctly when venue is known.
  let finalHome: number | null | undefined = pick.finalHomeGoals;
  let finalAway: number | null | undefined = pick.finalAwayGoals;
  if ((finalHome == null || finalAway == null)
      && venueKnown
      && typeof pick.matchScore === 'string') {
    const m = pick.matchScore.match(/^(\d+)\s*[-–]\s*(\d+)$/);
    if (m) {
      const subject = parseInt(m[1], 10);
      const opp = parseInt(m[2], 10);
      if (!Number.isNaN(subject) && !Number.isNaN(opp)) {
        if (venueLower === 'away') {
          finalHome = opp; finalAway = subject;
        } else {
          finalHome = subject; finalAway = opp;
        }
      }
    }
  }
  const homePoss = pick.homePoss;
  const awayPoss = pick.awayPoss;
  const projHomePoss = pick.projHomePoss;
  const projAwayPoss = pick.projAwayPoss;
  const hasActualPoss = homePoss != null && awayPoss != null;
  const hasProjPoss = projHomePoss != null && projAwayPoss != null;
  // Render the match-context block when we have either a trustable score OR a
  // possession projection to compare against. Projected possession alone is
  // enough to surface the "model said 60% — real was 48%" edge story.
  const trustOrient = hasFixtureNames || venueKnown;
  const showScoreLine = trustOrient && (
    ((settled || (live && hasLiveData)) && finalHome != null && finalAway != null)
    || hasActualPoss
    || hasProjPoss
  );
  const haveScoreNumbers = finalHome != null && finalAway != null;
  const subjectWon = settled && finalHome != null && finalAway != null && venueKnown && (
    (venueLower === 'home' && finalHome > finalAway) ||
    (venueLower === 'away' && finalAway > finalHome)
  );
  const subjectLost = settled && finalHome != null && finalAway != null && venueKnown && (
    (venueLower === 'home' && finalHome < finalAway) ||
    (venueLower === 'away' && finalAway < finalHome)
  );
  const homeColor = subjectWon && venueLower === 'home' ? Colors.success
    : subjectLost && venueLower === 'home' ? Colors.error
    : Colors.text;
  const awayColor = subjectWon && venueLower === 'away' ? Colors.success
    : subjectLost && venueLower === 'away' ? Colors.error
    : Colors.text;

  return (
    <View style={[styles.card, won && styles.cardWon, lost && styles.cardLost]}>
      {/* Row 1: player name left | [trash] [badge] right — all inline */}
      <View style={styles.cardTopRow}>
        <Text style={styles.cardPlayer} numberOfLines={1}>{pick.playerName}</Text>
        <View style={styles.cardRight}>
          {/* WEB-ONLY trash — inline with badge so it adds ZERO extra rows */}
          {Platform.OS === 'web' && onDelete && (
            // @ts-ignore raw DOM button intentional for reliable click
            <button
              type="button"
              onClick={(e: React.MouseEvent) => { e.preventDefault(); e.stopPropagation(); onDelete(); }}
              onPointerDown={(e: React.PointerEvent) => e.stopPropagation()}
              onMouseDown={(e: React.MouseEvent) => e.stopPropagation()}
              onTouchStart={(e: React.TouchEvent) => e.stopPropagation()}
              style={{ all: 'unset', cursor: 'pointer', padding: '3px 5px', borderRadius: 5, display: 'inline-flex', alignItems: 'center' }}
              aria-label="Delete pick"
            >
              <Ionicons name="trash-outline" size={12} color={Colors.error} />
            </button>
          )}
          {live && !won && !lost && hasLiveData && (
            <Reanimated.View entering={Platform.OS !== 'web' ? FadeInDown.duration(300) : undefined} style={styles.liveBadge}>
              <PulsingDot />
              <Text style={styles.liveText}>LIVE</Text>
            </Reanimated.View>
          )}
          {live && !won && !lost && !hasLiveData && (
            <View style={styles.pendingBadge}>
              <Ionicons name="time-outline" size={9} color={Colors.textSecondary} />
              <Text style={styles.pendingText}>PENDING</Text>
            </View>
          )}
          {won && (
            <View style={styles.wonBadge}>
              <Ionicons name="checkmark" size={9} color="#000" />
              <Text style={styles.wonText}>HIT</Text>
            </View>
          )}
          {lost && (
            <View style={styles.lostBadge}>
              <Ionicons name="close" size={9} color={Colors.error} />
              <Text style={styles.lostText}>MISS</Text>
            </View>
          )}
          {push && !won && !lost && (
            <View style={styles.pushBadge}>
              <Ionicons name="remove-outline" size={9} color={Colors.push} />
              <Text style={styles.pushText}>PUSH</Text>
            </View>
          )}
          {dnp && (
            <View style={styles.dnpBadge}>
              <Ionicons name="close" size={9} color={Colors.dnp} />
              <Text style={styles.dnpText}>DNP</Text>
            </View>
          )}
        </View>
      </View>

      {/* Row 2: meta + pick pill left | inline stats right */}
      <View style={styles.cardRow2}>
        <View style={styles.cardRow2Left}>
          <Text style={styles.cardMeta} numberOfLines={1}>
            {[pick.teamName, posLabel || null, pick.opponentName
              ? (pick.venue === 'away' ? `@ ${pick.opponentName}` : `vs ${pick.opponentName}`)
              : null]
              .filter(Boolean).join(' · ')}
          </Text>
          {effectiveDir && (
            <View style={styles.pickRow}>
              <View style={[styles.recPill, { backgroundColor: isOver ? Colors.successDim : isUnder ? Colors.errorDim : Colors.cardSecondary }]}>
                <Text style={[styles.recPillText, { color: recColor }]}>{effectiveDir}</Text>
              </View>
              <Text style={styles.pickDetail} numberOfLines={1}>
                {propLabel} · {pick.line}
              </Text>
              {(() => {
                // Confidence badge — visible on every live + settled card.
                // Color comes from the level the model assigned at pick-time.
                //
                // The backend stores confidenceScore as 0-100 (real model
                // output) PLUS a categorical level word. When the AI fails to
                // produce a real score the backend falls back to exactly 50 as
                // a placeholder — showing "50%" then is misleading because it
                // looks like a coin-flip when really it just means "no score
                // available". So when the score is the 50 placeholder (or
                // missing entirely) we display the level word only; otherwise
                // we show both ("85% STRONG").
                const confRaw = typeof pick.confidence === 'number' ? pick.confidence : null;
                const lvlRaw = (pick.confidenceLevel || '').trim();
                if (confRaw == null && !lvlRaw) return null;
                const lvl = lvlRaw.toLowerCase();
                const confColor =
                  lvl.startsWith('strong') || lvl.startsWith('high') ? Colors.success
                  : lvl.startsWith('weak') || lvl.startsWith('low') ? Colors.textTertiary
                  : Colors.primary; // medium / unknown
                const confPct = confRaw == null
                  ? null
                  : Math.round(confRaw > 1 ? confRaw : confRaw * 100);
                const isPlaceholder = confPct === 50; // backend default
                const showPct = confPct != null && !isPlaceholder;
                const confLabel = showPct
                  ? `${confPct}%${lvlRaw ? ' ' + lvlRaw.toUpperCase() : ''}`
                  : lvlRaw.toUpperCase();
                if (!confLabel) return null;
                return (
                  <View style={[styles.confBadge, { borderColor: confColor }]}>
                    <Text style={[styles.confBadgeText, { color: confColor }]} numberOfLines={1}>
                      {confLabel}
                    </Text>
                  </View>
                );
              })()}
              {pick.coinFlip && (
                <View style={styles.coinFlipBadge}>
                  <Text style={styles.coinFlipText}>~</Text>
                </View>
              )}
            </View>
          )}
        </View>
        {/* Inline stats: NOW (if live/settled) and PROJ */}
        <View style={styles.inlineStats}>
          {nowLabel && nowValue != null && (
            <View style={styles.inlineStat}>
              <Text style={[styles.inlineVal, { color: trackColor }]}>{Number(nowValue).toFixed(0)}</Text>
              <Text style={styles.inlineLbl}>{nowLabel}</Text>
            </View>
          )}
          {paceValue != null && (
            <View style={styles.inlineStat}>
              <Text style={[styles.inlineVal, { color: Colors.primary }]}>{Number(paceValue).toFixed(0)}</Text>
              <Text style={styles.inlineLbl}>{paceLabel}</Text>
            </View>
          )}
          {hitPct != null && (
            <View style={styles.inlineStat}>
              <Text style={[styles.inlineVal, { color: Colors.textSecondary }]}>{Math.round(hitPct)}%</Text>
              <Text style={styles.inlineLbl}>HIT</Text>
            </View>
          )}
        </View>
      </View>

      {/* Thin progress bar — only visible when live/settled with real data */}
      {lineValue != null && nowValue != null && (() => {
        const fillPct = Math.max(0, Math.min(100, (nowValue / Math.max(lineValue * 2, 1)) * 100));
        return (
          <View style={styles.trackBarOuter}>
            <View style={[styles.trackBarFill, { width: `${fillPct}%`, backgroundColor: trackColor }]} />
            <View style={[styles.trackBarMarker, { left: `${trackMarkerPct}%` }]} />
          </View>
        );
      })()}

      {/* Match context — single compact line: score + poss + fixture ID merged */}
      {(showScoreLine || pick.fixtureId != null) && (
        <View style={styles.matchCtxBlock}>
          <Text style={styles.matchCtxLine} numberOfLines={1} ellipsizeMode="tail">
            {showScoreLine ? (
              <>
                {haveScoreNumbers ? `${settled ? 'FT' : 'LIVE'} ` : ''}
                {haveScoreNumbers
                  ? `${homeTeamName || 'Home'} ${finalHome}–${finalAway} ${awayTeamName || 'Away'}`
                  : `${homeTeamName || 'Home'} vs ${awayTeamName || 'Away'}`}
                {hasActualPoss ? `  ·  ${homePoss}/${awayPoss}%` : ''}
                {hasProjPoss && !hasActualPoss ? `  ·  Proj ${Math.round(projHomePoss as number)}/${Math.round(projAwayPoss as number)}%` : ''}
                {hasActualPoss && hasProjPoss ? (() => {
                  const delta = Math.abs((projHomePoss as number) - (homePoss as number));
                  return ` Δ${delta.toFixed(0)}`;
                })() : ''}
                {pick.fixtureId != null ? `  ·  #${pick.fixtureId}` : ''}
              </>
            ) : (
              pick.fixtureId != null ? `#${pick.fixtureId}` : ''
            )}
          </Text>
        </View>
      )}

      {/* Live pace-divergence warning — fires when the in-match trend is running
          strongly against the pick's recommendation (e.g. opponent parks the bus
          after an early goal and the subject's pass volume balloons past a
          projected UNDER). Distinct from the quiet PACE/HIT inline numbers above —
          this is an explicit, hard-to-miss alert. */}
      {live && !won && !lost && pick.paceMismatch && pick.paceWarning && (
        <View style={styles.paceWarningBanner}>
          <Ionicons name="warning-outline" size={12} color={Colors.dnp} />
          <Text style={styles.paceWarningText} numberOfLines={2}>{pick.paceWarning}</Text>
        </View>
      )}


    </View>
  );
}

function RecordBar({ picks }: { picks: Pick[] }) {
  const hits = picks.filter(pickWon).length;
  const misses = picks.filter(pickLost).length;
  const dnps = picks.filter(pickDnp).length;
  const pending = picks.filter(isLive).length;
  const settled = hits + misses;
  const winPct = settled > 0 ? Math.round((hits / settled) * 100) : null;

  let streak = 0;
  const sorted = [...picks].sort((a, b) =>
    new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime()
  );
  for (const p of sorted) {
    if (pickWon(p)) streak++;
    else if (pickLost(p) || pickDnp(p)) break;
  }

  return (
    <View style={styles.recordBar}>
      <Text style={styles.recordLabel}>YOUR RECORD</Text>
      <View style={styles.recordStats}>
        <View style={styles.recordStat}>
          <Text style={[styles.recordVal, { color: Colors.success }]}>{hits}</Text>
          <Text style={styles.recordKey}>HITS</Text>
        </View>
        <View style={styles.recordStat}>
          <Text style={[styles.recordVal, { color: Colors.error }]}>{misses}</Text>
          <Text style={styles.recordKey}>MISS</Text>
        </View>
        <View style={styles.recordStat}>
          <Text style={[styles.recordVal, { color: Colors.textSecondary }]}>{pending}</Text>
          <Text style={styles.recordKey}>LIVE</Text>
        </View>
        <View style={styles.recordStat}>
          <Text style={[styles.recordVal, { color: Colors.dnp }]}>{dnps}</Text>
          <Text style={styles.recordKey}>DNP</Text>
        </View>
        <View style={styles.recordStat}>
          <Text style={[styles.recordVal, { color: Colors.primary }]}>
            {winPct != null ? `${winPct}%` : '—'}
          </Text>
          <Text style={styles.recordKey}>WIN%</Text>
        </View>
        <View style={styles.recordStat}>
          <Text style={[styles.recordVal, { color: Colors.accent }]}>
            {streak > 0 ? `${streak}W` : '—'}
          </Text>
          <Text style={styles.recordKey}>STRK</Text>
        </View>
      </View>
      <View style={styles.progressWrap}>
        <View style={styles.progressTrack}>
          <View
            style={[
              styles.progressFill,
              { width: `${picks.length > 0 ? Math.max(8, Math.min(100, (settled / picks.length) * 100)) : 0}%` },
            ]}
          />
        </View>
        <Text style={styles.progressText}>
          {settled}/{picks.length} settled
        </Text>
      </View>
    </View>
  );
}

function renderAnalysisBlocks(text: string, rec: string) {
  const isOver = rec === 'OVER';
  const isUnder = rec === 'UNDER';
  const recColor = isOver ? Colors.success : isUnder ? Colors.error : Colors.textSecondary;
  const paragraphs = text.split(/\n\n+/).filter(p => p.trim());
  const blocks: React.ReactElement[] = [];
  for (let i = 0; i < paragraphs.length; i++) {
    const para = paragraphs[i];
    const m = para.match(/^\*\*([^*]+)\*\*\s*([\s\S]*)/);
    if (m) {
      const section = m[1].trim();
      const body = m[2].trim().replace(/\*\*/g, '');
      if (section === 'Analysis') continue;
      if (section === 'Verdict') {
        blocks.push(
          <View key={i} style={mStyles.aiVerdictBlock}>
            <View style={[mStyles.aiVerdictPill, { backgroundColor: isOver ? 'rgba(57,255,20,0.12)' : 'rgba(255,59,48,0.12)' }]}>
              <Text style={[mStyles.aiVerdictLabel, { color: recColor }]}>VERDICT</Text>
            </View>
            <Text style={mStyles.aiVerdictText}>{body}</Text>
          </View>
        );
        continue;
      }
      if (section === 'TL;DR') {
        blocks.push(
          <View key={i} style={mStyles.aiTldrBlock}>
            <Text style={mStyles.aiTldrText}>{body}</Text>
          </View>
        );
        continue;
      }
      blocks.push(
        <View key={i} style={mStyles.aiSection}>
          <Text style={mStyles.aiSectionTitle}>{section.toUpperCase()}</Text>
          {body ? <Text style={mStyles.aiSectionBody}>{body}</Text> : null}
        </View>
      );
    } else {
      const plain = para.replace(/\*\*/g, '').trim();
      if (plain) blocks.push(<Text key={i} style={mStyles.aiSectionBody}>{plain}</Text>);
    }
  }
  return blocks;
}

function SportSectionHeader({
  sport, picks, expanded, onToggle,
}: {
  sport: SportKey; picks: Pick[]; expanded: boolean; onToggle: () => void;
}) {
  const { label, icon } = SPORT_META[sport];
  const hits   = picks.filter(pickWon).length;
  const misses = picks.filter(pickLost).length;
  const pushes = picks.filter(pickPush).length;
  const total  = hits + misses;
  const winPct = total > 0 ? Math.round((hits / total) * 100) : null;
  const pctColor = winPct == null ? Colors.textTertiary
    : winPct >= 60 ? Colors.success
    : winPct >= 50 ? Colors.primary
    : Colors.error;

  return (
    <TouchableOpacity
      onPress={onToggle}
      activeOpacity={0.75}
      style={secStyles.header}
    >
      <View style={secStyles.headerLeft}>
        <Text style={secStyles.headerIcon}>{icon}</Text>
        <Text style={secStyles.headerLabel}>{label}</Text>
        <View style={secStyles.countPill}>
          <Text style={secStyles.countText}>{picks.length}</Text>
        </View>
      </View>
      <View style={secStyles.headerRight}>
        <View style={secStyles.headerStats}>
          <Text style={[secStyles.statNum, { color: Colors.success }]}>
            {hits}<Text style={secStyles.statLbl}>H</Text>
          </Text>
          <Text style={secStyles.statDiv}> · </Text>
          <Text style={[secStyles.statNum, { color: Colors.error }]}>
            {misses}<Text style={secStyles.statLbl}>M</Text>
          </Text>
          {pushes > 0 && (
            <>
              <Text style={secStyles.statDiv}> · </Text>
              <Text style={[secStyles.statNum, { color: Colors.textTertiary }]}>
                {pushes}<Text style={secStyles.statLbl}>P</Text>
              </Text>
            </>
          )}
          <Text style={secStyles.statDiv}>  </Text>
          <Text style={[secStyles.winPct, { color: pctColor }]}>
            {winPct != null ? `${winPct}%` : '—'}
          </Text>
        </View>
        <Ionicons
          name={expanded ? 'chevron-up' : 'chevron-down'}
          size={14}
          color={Colors.textSecondary}
          style={{ marginLeft: 6 }}
        />
      </View>
    </TouchableOpacity>
  );
}

export default function PicksScreen() {
  const insets = useSafeAreaInsets();
  const { session, logout } = useAuth();
  const qc = useQueryClient();
  const topPad = Platform.OS === 'web' ? 67 : insets.top;
  const [activeTab, setActiveTab] = useState<Tab>('live');
  const [analysisModal, setAnalysisModal] = useState<{ pick: Pick; data: Record<string, unknown> | null; loading: boolean } | null>(null);
  // Which sport sections are expanded in history (default: all collapsed so all 3 headers visible)
  const [expandedSports, setExpandedSports] = useState<Set<SportKey>>(new Set());
  const toggleSport = useCallback((sport: SportKey) => {
    setExpandedSports(prev => {
      const next = new Set(prev);
      if (next.has(sport)) next.delete(sport);
      else next.add(sport);
      return next;
    });
  }, []);

  const sessionErrCount = useRef(0);
  const { data: picks = [], isLoading, refetch, isRefetching, error } = useQuery({
    queryKey: ['picks', session?.email],
    queryFn: async () => {
      if (!session) return [];
      try {
        const result = await listPicks(session.email, session.token);
        sessionErrCount.current = 0; // reset on success
        return result;
      } catch (e: unknown) {
        const msg = e instanceof Error ? e.message : String(e);
        // Only treat as SESSION_INVALID when the backend explicitly rejects the token
        // (actual HTTP 401 → api.ts throws 'Your session expired. Please sign in again.')
        const isAuthFailure = msg.includes('Your session expired') || msg.includes('Invalid session');
        if (isAuthFailure) {
          sessionErrCount.current += 1;
          // Need 3 consecutive auth failures before showing session-expired UI
          // (avoids false positives from a single network blip)
          if (sessionErrCount.current >= 3) throw new Error('SESSION_INVALID');
          // For first 2 auth failures: throw so React Query keeps stale cache
          // visible instead of replacing it with an empty array
          throw e;
        }
        // Server/network errors: throw so React Query preserves the last
        // successfully-fetched picks while it silently retries in the background.
        // Previously returning [] here would overwrite the cache with an empty
        // array, causing the "No picks" empty state to flash intermittently.
        throw e;
      }
    },
    enabled: !!session,
    staleTime: 10000,
    refetchInterval: 15000,
    refetchIntervalInBackground: false,
    retry: 1,
    retryDelay: 3000,
  });

  useFocusEffect(
    useCallback(() => {
      refetch();
      // React Query's refetchInterval handles ongoing polling.
      // A duplicate setInterval here caused near-simultaneous requests
      // on every 15s boundary → list flicker and navigation glitches.
    }, [refetch])
  );

  const deleteMutation = useMutation({
    mutationFn: (pickId: string) => {
      if (!session) throw new Error('Not authenticated');
      return deletePick(session.email, session.token, pickId);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['picks'] });
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    },
    onError: (e: Error) => Alert.alert('Delete failed', e.message),
  });

  const handleDelete = useCallback((pick: Pick) => {
    const id = pick.pickId || pick._id || pick.id;
    if (!id) return;
    if (Platform.OS === 'web') {
      if (window.confirm(`Remove ${pick.playerName}?`)) {
        deleteMutation.mutate(id);
      }
    } else {
      Alert.alert('Delete Pick', `Remove ${pick.playerName}?`, [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Delete', style: 'destructive', onPress: () => deleteMutation.mutate(id) },
      ]);
    }
  }, [deleteMutation]);

  const handlePickPress = useCallback(async (pick: Pick) => {
    const id = pick.pickId || pick._id || pick.id;
    if (!id || !session) return;
    setAnalysisModal({ pick, data: null, loading: true });
    try {
      const result = await fetchPickAnalysis(session.email, session.token, id);
      const analysis = result.found ? (result.analysis ?? null) : null;
      setAnalysisModal({ pick, data: analysis, loading: false });
      // Kick off on-demand review generation in background for settled picks without one
      const isSettled = pick.status === 'settled' && (pick.result === 'hit' || pick.result === 'miss');
      if (isSettled && !(pick as any).matchReview) {
        generateMatchReview(session.email, session.token, id).then(rev => {
          if (rev) {
            setAnalysisModal(prev =>
              prev?.pick === pick ? { ...prev, pick: { ...prev.pick, matchReview: rev } as any } : prev
            );
          }
        }).catch(() => {});
      }
    } catch {
      setAnalysisModal({ pick, data: null, loading: false });
    }
  }, [session]);

  const live = picks.filter(isLive);
  const history = picks.filter(isSettled);

  // Split history into sport buckets (Soccer → MLB → CS2 order)
  const SPORT_ORDER: SportKey[] = ['soccer', 'mlb', 'cs2'];
  const bySport: Record<SportKey, Pick[]> = { soccer: [], mlb: [], cs2: [] };
  for (const p of history) bySport[getSport(p)].push(p);

  // Build flat accordion list: header items + pick items for expanded sections
  type AccordionItem =
    | { type: 'header'; sport: SportKey }
    | { type: 'pick';   sport: SportKey; pick: Pick };

  const accordionData: AccordionItem[] = [];
  for (const sport of SPORT_ORDER) {
    if (bySport[sport].length === 0) continue;
    accordionData.push({ type: 'header', sport });
    if (expandedSports.has(sport)) {
      for (const pick of bySport[sport]) {
        accordionData.push({ type: 'pick', sport, pick });
      }
    }
  }

  const modalRec = ((analysisModal?.data?.recommendation ?? analysisModal?.pick?.recommendation) as string | undefined)?.toUpperCase() ?? '';
  const modalIsOver = modalRec === 'OVER';
  const modalIsUnder = modalRec === 'UNDER';
  const modalRecColor = modalIsOver ? Colors.success : modalIsUnder ? Colors.error : Colors.textSecondary;
  const _rawModalText = (analysisModal?.data?.reasoning ?? analysisModal?.pick?.reasoning ?? analysisModal?.data?.tacticalBreakdown ?? analysisModal?.pick?.tacticalBreakdown ?? analysisModal?.data?.explanation ?? analysisModal?.data?.sharpSummary ?? analysisModal?.pick?.sharpSummary) as string | undefined;
  // Filter out stale placeholder text that was stored while AI was still pending
  const modalText = (_rawModalText && !_rawModalText.startsWith('AI analysis loading')) ? _rawModalText : undefined;
  const modalAlerts = (analysisModal?.data?.tacticalAlerts ?? analysisModal?.pick?.tacticalAlerts ?? []) as string[];

  return (
    <View style={[styles.root, { paddingTop: topPad }]}>
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>My Picks</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
        <View style={styles.tabToggle}>
          {(['live', 'history'] as Tab[]).map(t => (
            <TouchableOpacity
              key={t}
              style={[styles.toggle, activeTab === t && styles.toggleActive]}
              onPress={() => { setActiveTab(t); Haptics.selectionAsync(); }}
            >
              {t === 'live' && live.length > 0 && activeTab !== 'live' && (
                <View style={styles.tabDot} />
              )}
              <Text style={[styles.toggleText, activeTab === t && styles.toggleTextActive]}>
                {t === 'live' ? `Live${live.length > 0 ? ` (${live.length})` : ''}` : `History${history.length > 0 ? ` (${history.length})` : ''}`}
              </Text>
            </TouchableOpacity>
          ))}
        </View>
        <NotificationBell />
        </View>
      </View>

      {/* Record bar — always show if any picks exist */}
      {picks.length > 0 && <RecordBar picks={picks} />}

      {error && (error as Error).message === 'SESSION_INVALID' ? (
        <View style={styles.center}>
          <Ionicons name="lock-closed-outline" size={44} color={Colors.textTertiary} />
          <Text style={[styles.emptyTitle, { marginTop: 12 }]}>Session expired</Text>
          <Text style={[styles.emptySub, { textAlign: 'center', marginTop: 6 }]}>
            Your session timed out. Sign out and back in to restore your picks.
          </Text>
          <TouchableOpacity onPress={() => logout()} style={{ marginTop: 18, backgroundColor: Colors.primary, paddingHorizontal: 24, paddingVertical: 10, borderRadius: 8 }}>
            <Text style={{ color: '#000', fontWeight: '800', fontSize: 14 }}>Sign Out & Re-login</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => refetch()} style={{ marginTop: 12 }}>
            <Text style={{ color: Colors.textTertiary, fontWeight: '600', fontSize: 13 }}>Retry</Text>
          </TouchableOpacity>
        </View>
      ) : isLoading ? (
        <View style={styles.center}>
          <ActivityIndicator color={Colors.primary} size="large" />
        </View>
      ) : activeTab === 'live' && live.length === 0 ? (
        <Reanimated.View entering={Platform.OS !== 'web' ? FadeInDown.duration(400).springify() : undefined} style={styles.empty}>
          <View style={styles.emptyIconWrap}>
            <Ionicons name="radio-outline" size={36} color={Colors.primary} />
          </View>
          <Text style={styles.emptyTitle}>No live picks</Text>
          <Text style={styles.emptySub}>Run a prediction on the Predict tab and save it — it'll appear here and update live as your game plays.</Text>
          <TouchableOpacity style={styles.emptyAction} onPress={() => router.replace('/(tabs)/scan')}>
            <Ionicons name="scan-outline" size={14} color="#000" />
            <Text style={styles.emptyActionText}>Make a Prediction</Text>
          </TouchableOpacity>
        </Reanimated.View>
      ) : activeTab === 'history' && history.length === 0 ? (
        <Reanimated.View entering={Platform.OS !== 'web' ? FadeInDown.duration(400).springify() : undefined} style={styles.empty}>
          <View style={styles.emptyIconWrap}>
            <Ionicons name="checkmark-circle-outline" size={36} color={Colors.textTertiary} />
          </View>
          <Text style={styles.emptyTitle}>No settled picks yet</Text>
          <Text style={styles.emptySub}>Your record will appear here once your saved picks have games that finish. Check back after kickoff.</Text>
        </Reanimated.View>
      ) : activeTab === 'live' ? (
        <FlatList
          data={live}
          keyExtractor={(item, i) => item.pickId || item._id || item.id || String(i)}
          initialNumToRender={8}
          maxToRenderPerBatch={8}
          renderItem={({ item }) => {
            const tappable = isLive(item) && !pickWon(item) && !pickLost(item);
            const onDeleteForItem = () => handleDelete(item);
            const card = tappable ? (
              <Pressable
                onPress={() => {
                  try { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light); } catch {}
                  handlePickPress(item);
                }}
                style={({ pressed }) => [{ opacity: pressed ? 0.88 : 1 }]}
              >
                <PickCard pick={item} onDelete={onDeleteForItem} />
              </Pressable>
            ) : (
              <PickCard pick={item} onDelete={onDeleteForItem} />
            );
            return <SwipeablePickRow onDelete={onDeleteForItem}>{card}</SwipeablePickRow>;
          }}
          contentContainerStyle={styles.list}
          refreshControl={<RefreshControl refreshing={isRefetching} onRefresh={refetch} tintColor={Colors.primary} />}
          showsVerticalScrollIndicator={false}
        />
      ) : (
        /* ── HISTORY: collapsible sport accordion ── */
        <FlatList
          data={accordionData}
          initialNumToRender={12}
          maxToRenderPerBatch={15}
          keyExtractor={(item, i) =>
            item.type === 'header'
              ? `hdr-${item.sport}`
              : `pick-${(item as { type: 'pick'; pick: Pick; sport: SportKey }).pick.pickId || i}`
          }
          renderItem={({ item }) => {
            if (item.type === 'header') {
              return (
                <SportSectionHeader
                  sport={item.sport}
                  picks={bySport[item.sport]}
                  expanded={expandedSports.has(item.sport)}
                  onToggle={() => {
                    try { Haptics.selectionAsync(); } catch {}
                    toggleSport(item.sport);
                  }}
                />
              );
            }
            const pickItem = item.pick;
            const onDeleteForItem = () => handleDelete(pickItem);
            return (
              <SwipeablePickRow onDelete={onDeleteForItem}>
                <Pressable
                  onPress={() => handlePickPress(pickItem)}
                  style={({ pressed }) => [{ opacity: pressed ? 0.92 : 1 }]}
                >
                  <PickCard pick={pickItem} onDelete={onDeleteForItem} />
                </Pressable>
              </SwipeablePickRow>
            );
          }}
          contentContainerStyle={[styles.list, { paddingTop: 4 }]}
          refreshControl={<RefreshControl refreshing={isRefetching} onRefresh={refetch} tintColor={Colors.primary} />}
          showsVerticalScrollIndicator={false}
        />
      )}

      {/* ── Analysis Modal ── */}
      <Modal
        visible={analysisModal !== null}
        animationType="slide"
        transparent
        onRequestClose={() => setAnalysisModal(null)}
      >
        <View style={mStyles.modalContainer}>
          <Pressable style={mStyles.modalBackdrop} onPress={() => setAnalysisModal(null)} />
          <View style={mStyles.modalSheet}>
          {/* Handle */}
          <View style={mStyles.modalHandle} />

          {/* Header */}
          <View style={mStyles.modalHeader}>
            <View style={mStyles.modalPlayerInfo}>
              <Text style={mStyles.modalPlayer} numberOfLines={1}>{analysisModal?.pick.playerName}</Text>
              <Text style={mStyles.modalMeta} numberOfLines={1}>
                {[analysisModal?.pick.teamName, analysisModal?.pick.opponentName
                  ? (analysisModal?.pick.venue === 'away' ? `@ ${analysisModal?.pick.opponentName}` : `vs ${analysisModal?.pick.opponentName}`)
                  : null].filter(Boolean).join(' · ')}
              </Text>
            </View>
            <View style={mStyles.modalRight}>
              {modalRec ? (
                <View style={[mStyles.modalRecBadge, { backgroundColor: modalIsOver ? Colors.successDim : modalIsUnder ? Colors.errorDim : Colors.cardSecondary }]}>
                  <Text style={[mStyles.modalRecText, { color: modalRecColor }]}>{modalRec}</Text>
                </View>
              ) : null}
              <TouchableOpacity onPress={() => setAnalysisModal(null)} style={mStyles.modalClose}>
                <Ionicons name="close" size={18} color={Colors.textSecondary} />
              </TouchableOpacity>
            </View>
          </View>

          {/* Prop row */}
          <View style={mStyles.modalPropRow}>
            <Text style={mStyles.modalPropText}>
              {PROP_LABELS[analysisModal?.pick.propType ?? ''] ?? analysisModal?.pick.propType} · Line {analysisModal?.pick.line}
            </Text>
            {analysisModal?.data?.projectedValue != null && (
              <Text style={[mStyles.modalProjText, { color: modalRecColor }]}>
                Proj {(analysisModal.data.projectedValue as number).toFixed(1)}
              </Text>
            )}
          </View>

          {/* Edge-gap pill row — surfaces how far projection sits from the line
              and whether league calibration / game-script informed the call. */}
          {(() => {
            const bm: any = (analysisModal?.data as any)?.bayesianMetrics ?? (analysisModal?.pick?.bayesianMetrics as any) ?? {};
            const gapPct = bm.edgeGapPct;
            const gapBand = bm.edgeGapBand;
            const lcal = bm.leagueCalibration;
            const gs = bm.gameScript;
            if (gapPct == null && !lcal?.applied && !gs?.applied) return null;
            const bandColor = gapBand === 'DEEP' ? Colors.success
              : gapBand === 'STRONG' ? Colors.success
              : gapBand === 'MODERATE' ? Colors.primary
              : Colors.textSecondary;
            return (
              <View style={mStyles.modalEdgeRow}>
                {gapPct != null && (
                  <View style={[mStyles.edgePill, { borderColor: bandColor }]}>
                    <Text style={[mStyles.edgePillText, { color: bandColor }]}>
                      {gapBand ?? 'EDGE'} · {gapPct > 0 ? '+' : ''}{Number(gapPct).toFixed(1)}%
                    </Text>
                  </View>
                )}
                {lcal?.applied && lcal?.n > 0 && (
                  <View style={[mStyles.edgePill, { borderColor: Colors.borderSubtle }]}>
                    <Text style={[mStyles.edgePillText, { color: Colors.textSecondary }]}>
                      League calib · n={lcal.n} · {Math.round((lcal.hit_rate ?? 0) * 100)}% hit
                    </Text>
                  </View>
                )}
                {gs?.applied && (
                  <View style={[mStyles.edgePill, { borderColor: Colors.borderSubtle }]}>
                    <Text style={[mStyles.edgePillText, { color: Colors.textSecondary }]}>
                      Game-script · ×{Number(gs.multiplier).toFixed(3)}
                    </Text>
                  </View>
                )}
              </View>
            );
          })()}

          {/* ── Game Script Banner (on analysis modal) ── */}
          {(() => {
            const gs = (analysisModal?.data as any)?.gameScript ?? analysisModal?.pick?.gameScript;
            if (!gs || !gs.dominant) return null;
            const color = gs.color || '#60A5FA';
            const iconMap: Record<string, string> = {
              'low_scoring': 'shield', 'high_scoring': 'flame',
              'open_close': 'analytics', 'home_blowout': 'trending-up',
              'away_blowout': 'trending-down',
            };
            const icon = (iconMap[gs.dominant] || 'analytics') as any;
            return (
              <View style={[mStyles.gsBanner, { borderColor: color + '44' }]}>
                <View style={[mStyles.gsBannerStripe, { backgroundColor: color }]} />
                <View style={mStyles.gsBannerBody}>
                  <View style={mStyles.gsBannerHeader}>
                    <Ionicons name={icon} size={14} color={color} />
                    <Text style={[mStyles.gsBannerLabel, { color }]}>GAME SCRIPT</Text>
                    <Text style={mStyles.gsBannerProb}>{Math.round((gs.dominant_probability || 0) * 100)}%</Text>
                  </View>
                  <Text style={[mStyles.gsBannerTitle, { color }]}>{gs.key_finding}</Text>
                  {gs.scenarios && gs.scenarios.length > 1 && (
                    <View style={mStyles.gsBannerScenarios}>
                      {gs.scenarios.slice(0, 3).map((s: any, i: number) => (
                        <View key={i} style={mStyles.gsBannerChip}>
                          <Text style={mStyles.gsBannerChipName}>{s.name}</Text>
                          <Text style={[mStyles.gsBannerChipPct, { color }]}>{Math.round(s.probability * 100)}%</Text>
                        </View>
                      ))}
                    </View>
                  )}
                  {gs.expected_total_goals != null && (
                    <Text style={mStyles.gsBannerSub}>
                      Expected {gs.expected_total_goals} total goals
                    </Text>
                  )}
                </View>
              </View>
            );
          })()}

          {/* Moneyline Odds — always shown; "Not available" when no data */}
          {(() => {
            const ml = (analysisModal?.data as any)?.moneyline ?? (analysisModal?.pick as any)?.moneyline;
            const formatOdds = (val: string) => {
              if (!val || val === 'N/A') return '';
              const n = parseFloat(val);
              if (isNaN(n)) return val;
              if (n > 1 && n < 50) {
                if (n >= 2) return `+${Math.round((n - 1) * 100)}`;
                return `${Math.round(-100 / (n - 1))}`;
              }
              return n > 0 ? `+${Math.round(n)}` : `${Math.round(n)}`;
            };
            if (ml) {
              const h = formatOdds(ml.home);
              const d = formatOdds(ml.draw);
              const a = formatOdds(ml.away);
              if (h || d || a) {
                const teamShort = (analysisModal?.pick?.teamName || 'HOME').split(' ').pop()?.slice(0, 5).toUpperCase() || 'HOME';
                const oppShort  = (analysisModal?.pick?.opponentName || 'AWAY').split(' ').pop()?.slice(0, 5).toUpperCase() || 'AWAY';
                const isHome = analysisModal?.pick?.venue !== 'away';
                const t1 = isHome ? teamShort : oppShort;
                const t2 = isHome ? oppShort  : teamShort;
                return (
                  <View style={mStyles.oddsRow}>
                    <View style={mStyles.oddsHeader}>
                      <Ionicons name="cash-outline" size={11} color={Colors.textTertiary} />
                      <Text style={mStyles.oddsLabel}>MONEYLINE</Text>
                    </View>
                    <View style={mStyles.oddsPills}>
                      <View style={mStyles.oddsPill}>
                        <Text style={mStyles.oddsPillTeam}>{t1}</Text>
                        <Text style={mStyles.oddsPillVal}>{h}</Text>
                      </View>
                      {d ? (
                        <View style={mStyles.oddsPill}>
                          <Text style={mStyles.oddsPillTeam}>DRAW</Text>
                          <Text style={mStyles.oddsPillVal}>{d}</Text>
                        </View>
                      ) : null}
                      <View style={mStyles.oddsPill}>
                        <Text style={mStyles.oddsPillTeam}>{t2}</Text>
                        <Text style={mStyles.oddsPillVal}>{a}</Text>
                      </View>
                    </View>
                    <Text style={mStyles.oddsDisclaim}>Indicative · verify with your sportsbook</Text>
                  </View>
                );
              }
            }
            return (
              <View style={mStyles.oddsRow}>
                <View style={mStyles.oddsHeader}>
                  <Ionicons name="cash-outline" size={11} color={Colors.textTertiary} />
                  <Text style={mStyles.oddsLabel}>MONEYLINE</Text>
                </View>
                <Text style={mStyles.oddsUnavail}>Not available for this market</Text>
              </View>
            );
          })()}

          <View style={mStyles.modalDivider} />

          {/* Body */}
          <ScrollView style={mStyles.modalScroll} contentContainerStyle={mStyles.modalScrollContent} showsVerticalScrollIndicator={false}>

            {/* ── POST-MATCH BREAKDOWN (settled picks only, shown FIRST and PROMINENT) ── */}
            {(() => {
              const pick = analysisModal?.pick as any;
              const isSettled = pick?.status === 'settled' && (pick?.result === 'hit' || pick?.result === 'miss');
              if (!isSettled) return null;
              const review = pick?.matchReview as string | undefined;
              const res = (pick?.result || '').toLowerCase();
              const isHit = res === 'hit';
              const accent = isHit ? Colors.primary : '#FF6B35';
              const bgColor = isHit ? 'rgba(57,255,20,0.05)' : 'rgba(255,107,53,0.05)';
              return (
                <View style={{
                  borderWidth: 1, borderColor: accent + '55',
                  borderLeftWidth: 4, borderLeftColor: accent,
                  backgroundColor: bgColor, borderRadius: 10,
                  paddingVertical: 14, paddingHorizontal: 14, marginBottom: 18,
                }}>
                  {/* Header row */}
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 10 }}>
                    <Ionicons
                      name={isHit ? 'checkmark-circle' : 'close-circle'}
                      size={16} color={accent}
                    />
                    <Text style={{ fontSize: 11, fontWeight: '800', color: accent, letterSpacing: 1.4 }}>
                      {isHit ? 'VERDICT: HIT' : 'VERDICT: MISS'}
                    </Text>
                    <View style={{
                      marginLeft: 'auto', backgroundColor: accent + '22',
                      borderRadius: 4, paddingHorizontal: 7, paddingVertical: 2,
                    }}>
                      <Text style={{ fontSize: 9, fontWeight: '700', color: accent, letterSpacing: 0.8 }}>
                        POST-MATCH AI
                      </Text>
                    </View>
                  </View>
                  {review ? (
                    <Text style={{ fontSize: 14, color: Colors.text, lineHeight: 22, letterSpacing: 0.1 }}>
                      {review}
                    </Text>
                  ) : (
                    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                      <ActivityIndicator size="small" color={accent} />
                      <Text style={{ fontSize: 13, color: Colors.textSecondary }}>
                        Generating match breakdown…
                      </Text>
                    </View>
                  )}
                </View>
              );
            })()}

            {/* ── PRE-MATCH INTEL section label (settled picks show it as secondary) ── */}
            {(() => {
              const pick = analysisModal?.pick as any;
              const isSettled = pick?.status === 'settled' && (pick?.result === 'hit' || pick?.result === 'miss');
              if (!isSettled || !modalText) return null;
              return (
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                  <View style={{ flex: 1, height: 1, backgroundColor: Colors.borderSubtle }} />
                  <Text style={{ fontSize: 9, fontWeight: '700', color: Colors.textTertiary, letterSpacing: 1.2 }}>
                    PRE-MATCH INTEL
                  </Text>
                  <View style={{ flex: 1, height: 1, backgroundColor: Colors.borderSubtle }} />
                </View>
              );
            })()}

            {/* ── Analysis body (pre-match) ── */}
            {analysisModal?.loading ? (
              <View style={mStyles.modalLoading}>
                <ActivityIndicator color={Colors.primary} />
                <Text style={mStyles.modalLoadingText}>Loading analysis…</Text>
              </View>
            ) : !modalText ? (
              (() => {
                const pick = analysisModal?.pick as any;
                const isSettled = pick?.status === 'settled' && (pick?.result === 'hit' || pick?.result === 'miss');
                if (isSettled) return null;
                return (
                  <View style={mStyles.modalLoading}>
                    <Ionicons name="analytics-outline" size={32} color={Colors.textTertiary} />
                    <Text style={mStyles.modalLoadingText}>No analysis found for this pick yet.</Text>
                  </View>
                );
              })()
            ) : (
              <View style={mStyles.aiBlocks}>
                {renderAnalysisBlocks(modalText, modalRec)}

                {/* ── SIGNAL ALERTS — full-width readable cards, NOT cut-off pills ── */}
                {modalAlerts.length > 0 && (
                  <View style={{ gap: 8, marginTop: 4 }}>
                    {modalAlerts.slice(0, 5).map((alert, i) => {
                      const lower = alert.toLowerCase();
                      const isLineDeviation = lower.includes('line deviation') || lower.includes('edgegap') || lower.includes('deviation');
                      const isRisk = lower.includes('risk') || lower.includes('dismissal') || lower.includes('invalid') || lower.includes('flip') || lower.includes('void') || lower.includes('red card');
                      const isBoost = lower.includes('boost') || lower.includes('infl') || lower.includes('rise') || lower.includes('high');
                      const alertColor = isRisk ? '#FF6B35' : isLineDeviation ? '#60A5FA' : isBoost ? Colors.primary : '#60A5FA';
                      const iconName: any = isRisk ? 'warning' : isLineDeviation ? 'stats-chart' : isBoost ? 'trending-up' : 'information-circle';
                      const label = isLineDeviation ? 'LINE INTEL' : isRisk ? 'RISK SIGNAL' : 'SIGNAL';
                      return (
                        <View key={i} style={{
                          backgroundColor: alertColor + '0D',
                          borderRadius: 8, padding: 10,
                          borderWidth: 1, borderColor: alertColor + '33',
                          borderLeftWidth: 3, borderLeftColor: alertColor,
                        }}>
                          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5, marginBottom: 4 }}>
                            <Ionicons name={iconName} size={11} color={alertColor} />
                            <Text style={{ fontSize: 9, fontWeight: '800', color: alertColor, letterSpacing: 1.1 }}>
                              {label}
                            </Text>
                          </View>
                          <Text style={{ fontSize: 12.5, color: Colors.text, lineHeight: 18 }}>{alert}</Text>
                        </View>
                      );
                    })}
                  </View>
                )}
              </View>
            )}
          </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const secStyles = StyleSheet.create({
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginHorizontal: 16,
    marginTop: 14,
    marginBottom: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: Colors.card,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: Colors.border,
  },
  headerLeft:  { flexDirection: 'row', alignItems: 'center', gap: 7 },
  headerRight: { flexDirection: 'row', alignItems: 'center' },
  headerIcon:  { fontSize: 16 },
  headerLabel: { fontSize: 13, fontWeight: '800', color: Colors.text, letterSpacing: 0.3 },
  countPill: {
    backgroundColor: Colors.cardSecondary,
    borderRadius: 999, paddingHorizontal: 7, paddingVertical: 1,
  },
  countText:   { fontSize: 10, fontWeight: '700', color: Colors.textSecondary },
  headerStats: { flexDirection: 'row', alignItems: 'baseline' },
  statNum:     { fontSize: 13, fontWeight: '800' },
  statLbl:     { fontSize: 9, fontWeight: '600', color: Colors.textTertiary },
  statDiv:     { fontSize: 11, color: Colors.textTertiary },
  winPct:      { fontSize: 14, fontWeight: '800' },
});

const mStyles = StyleSheet.create({
  modalContainer: { flex: 1, justifyContent: 'flex-end' },
  modalBackdrop: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.6)' },
  modalSheet: {
    backgroundColor: Colors.card,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    maxHeight: '82%',
    borderWidth: 1,
    borderColor: Colors.borderSubtle,
    borderBottomWidth: 0,
  },
  modalHandle: {
    width: 36, height: 4, borderRadius: 2,
    backgroundColor: Colors.border, alignSelf: 'center', marginTop: 10,
  },
  modalHeader: {
    flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between',
    paddingHorizontal: 18, paddingTop: 14, paddingBottom: 10, gap: 10,
  },
  modalPlayerInfo: { flex: 1 },
  modalPlayer: { fontSize: 18, fontWeight: '800', color: Colors.text },
  modalMeta: { fontSize: 12, color: Colors.textSecondary, marginTop: 2 },
  modalRight: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  modalRecBadge: { paddingHorizontal: 12, paddingVertical: 5, borderRadius: 8 },
  modalRecText: { fontSize: 13, fontWeight: '800', letterSpacing: 0.5 },
  modalClose: { padding: 4 },
  modalPropRow: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 18, paddingBottom: 12,
  },
  modalPropText: { fontSize: 13, color: Colors.textSecondary },
  modalProjText: { fontSize: 14, fontWeight: '700' },
  modalEdgeRow: {
    flexDirection: 'row', flexWrap: 'wrap', gap: 6,
    paddingHorizontal: 18, paddingTop: 4, paddingBottom: 8,
  },
  edgePill: {
    paddingHorizontal: 8, paddingVertical: 3,
    borderRadius: 6, borderWidth: 1,
    backgroundColor: Colors.cardSecondary,
  },
  edgePillText: { fontSize: 11, fontWeight: '700', letterSpacing: 0.3 },
  modalDivider: { height: 1, backgroundColor: Colors.borderSubtle },
  modalScroll: { flex: 0 },
  modalScrollContent: { padding: 18, paddingBottom: 40 },
  modalLoading: { alignItems: 'center', paddingVertical: 40, gap: 14 },
  modalLoadingText: { fontSize: 14, color: Colors.textSecondary, textAlign: 'center' },
  aiBlocks: { gap: 16 },
  oddsRow: { marginHorizontal: 16, marginBottom: 10, gap: 5 },
  oddsHeader: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  oddsLabel: { fontSize: 9, fontWeight: '800', color: Colors.textTertiary, letterSpacing: 1.2 },
  oddsPills: { flexDirection: 'row', gap: 6 },
  oddsPill: {
    flex: 1, backgroundColor: Colors.cardSecondary, borderRadius: 8,
    paddingVertical: 7, paddingHorizontal: 8, alignItems: 'center', gap: 2,
  },
  oddsPillTeam: { fontSize: 9, fontWeight: '700', color: Colors.textTertiary, letterSpacing: 0.8 },
  oddsPillVal: { fontSize: 15, fontWeight: '800', color: Colors.text },
  oddsDisclaim: { fontSize: 9, color: Colors.textTertiary, fontStyle: 'italic', marginTop: 1 },
  oddsUnavail: { fontSize: 12, color: Colors.textTertiary, fontStyle: 'italic' },
  aiVerdictBlock: {
    backgroundColor: 'rgba(57,255,20,0.06)',
    borderLeftWidth: 3, borderLeftColor: Colors.primary,
    borderRadius: 8, padding: 12, gap: 6,
  },
  aiVerdictPill: { alignSelf: 'flex-start', borderRadius: 4, paddingHorizontal: 7, paddingVertical: 2 },
  aiVerdictLabel: { fontSize: 9, fontWeight: '800', letterSpacing: 1.5 },
  aiVerdictText: { fontSize: 14, fontWeight: '600', lineHeight: 21, color: Colors.text },
  aiTldrBlock: { backgroundColor: Colors.cardSecondary, borderRadius: 8, padding: 12 },
  aiTldrText: { fontSize: 12, color: Colors.textSecondary, lineHeight: 18, fontStyle: 'italic' },
  aiSection: { gap: 5 },
  aiSectionTitle: { fontSize: 10, fontWeight: '800', color: Colors.primary, letterSpacing: 1.2 },
  aiSectionBody: { fontSize: 13, color: Colors.textSecondary, lineHeight: 20 },
  // ── Game Script Banner (analysis modal)
  gsBanner: {
    flexDirection: 'row',
    marginHorizontal: 16,
    marginBottom: 10,
    borderRadius: 10,
    borderWidth: 1,
    overflow: 'hidden',
    backgroundColor: '#0a0a0a',
  },
  gsBannerStripe: { width: 4 },
  gsBannerBody: { flex: 1, padding: 12, gap: 6 },
  gsBannerHeader: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  gsBannerLabel: { fontSize: 9, fontWeight: '800', letterSpacing: 1.2 },
  gsBannerProb: { fontSize: 11, fontWeight: '800', color: '#fff', marginLeft: 'auto' },
  gsBannerTitle: { fontSize: 15, fontWeight: '800', letterSpacing: 0.3 },
  gsBannerScenarios: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 2 },
  gsBannerChip: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: '#151515', borderRadius: 5,
    paddingHorizontal: 7, paddingVertical: 3,
  },
  gsBannerChipName: { fontSize: 9, color: '#9CA3AF', fontWeight: '600' },
  gsBannerChipPct: { fontSize: 9, fontWeight: '800' },
  gsBannerSub: { fontSize: 10, color: '#6B7280', fontWeight: '500', marginTop: 2 },
});

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: Colors.background },
  header: {
    paddingHorizontal: 20, paddingBottom: 12,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
  },
  headerTitle: { fontSize: 28, fontWeight: '800', color: Colors.text },
  tabToggle: {
    flexDirection: 'row', backgroundColor: Colors.card,
    borderRadius: 10, borderWidth: 1, borderColor: Colors.border, padding: 3,
  },
  toggle: { paddingVertical: 7, paddingHorizontal: 14, borderRadius: 8, flexDirection: 'row', alignItems: 'center', gap: 5 },
  toggleActive: { backgroundColor: Colors.primary },
  toggleText: { fontSize: 13, fontWeight: '600', color: Colors.textSecondary },
  toggleTextActive: { color: '#000' },
  tabDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: Colors.primary },
  progressWrap: { gap: 6, marginTop: 2 },
  progressTrack: {
    height: 6,
    borderRadius: 999,
    backgroundColor: Colors.cardSecondary,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%' as unknown as number,
    borderRadius: 999,
    backgroundColor: Colors.primary,
  },
  progressText: { fontSize: 10, color: Colors.textTertiary, fontWeight: '600', textAlign: 'right' },

  recordBar: {
    marginHorizontal: 20, marginBottom: 12, backgroundColor: Colors.card,
    borderRadius: Colors.radius, borderWidth: 1, borderColor: Colors.border, padding: 14, gap: 8,
  },
  recordLabel: { fontSize: 10, fontWeight: '700', color: Colors.textTertiary, letterSpacing: 1.5 },
  recordStats: { flexDirection: 'row', justifyContent: 'space-between' },
  recordStat: { alignItems: 'center', flex: 1 },
  recordVal: { fontSize: 18, fontWeight: '800', color: Colors.text },
  recordKey: { fontSize: 9, color: Colors.textTertiary, fontWeight: '600', letterSpacing: 0.5, marginTop: 2 },

  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, paddingHorizontal: 40, paddingTop: 60, paddingBottom: 40 },
  emptyIconWrap: {
    width: 72, height: 72, borderRadius: 36,
    backgroundColor: 'rgba(57,255,20,0.06)',
    borderWidth: 1, borderColor: 'rgba(57,255,20,0.12)',
    alignItems: 'center', justifyContent: 'center',
    marginBottom: 4,
  },
  emptyTitle: { fontSize: 18, fontWeight: '700', color: Colors.text },
  emptySub: { fontSize: 14, color: Colors.textSecondary, textAlign: 'center', lineHeight: 21 },
  emptyAction: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: Colors.primary, borderRadius: 10,
    paddingHorizontal: 20, paddingVertical: 11, marginTop: 6,
  },
  emptyActionText: { color: '#000', fontWeight: '800', fontSize: 14 },
  list: { paddingHorizontal: 12, paddingBottom: 40, gap: 6 },

  card: {
    backgroundColor: Colors.card, borderRadius: 12,
    paddingHorizontal: 12, paddingVertical: 7,
    borderWidth: 1, borderColor: Colors.borderSubtle, gap: 3,
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.12, shadowRadius: 3, elevation: 2,
  },
  cardWon: { borderColor: 'rgba(57,255,20,0.35)', shadowColor: 'rgba(57,255,20,0.15)' },
  cardLost: { borderColor: 'rgba(255,59,48,0.3)' },

  cardTopRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  cardRight: { flexDirection: 'row', alignItems: 'center', gap: 6, flexShrink: 0 },
  cardPlayer: { fontSize: 13, fontWeight: '800', color: Colors.text, flex: 1, letterSpacing: 0.1 },
  cardMeta: { fontSize: 10, color: Colors.textTertiary, letterSpacing: 0.1, marginBottom: 1 },

  cardRow2: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 6 },
  cardRow2Left: { flex: 1, gap: 2 },
  inlineStats: { flexDirection: 'row', alignItems: 'center', gap: 10, flexShrink: 0 },
  inlineStat: { alignItems: 'center', gap: 1, minWidth: 28 },
  inlineVal: { fontSize: 15, fontWeight: '800', color: Colors.text },
  inlineLbl: { fontSize: 8, color: Colors.textTertiary, fontWeight: '600', letterSpacing: 0.8 },

  liveBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(57,255,20,0.1)', borderRadius: 7,
    paddingHorizontal: 8, paddingVertical: 4,
    borderWidth: 1, borderColor: 'rgba(57,255,20,0.25)',
  },
  liveDot: { width: 5, height: 5, borderRadius: 2.5, backgroundColor: Colors.primary },
  liveText: { fontSize: 10, color: Colors.primary, fontWeight: '800', letterSpacing: 0.5 },
  pendingBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: 'rgba(255,255,255,0.05)', borderRadius: 7,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)',
    paddingHorizontal: 8, paddingVertical: 4,
  },
  pendingText: { fontSize: 10, color: Colors.textSecondary, fontWeight: '600', letterSpacing: 0.5 },
  wonBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: Colors.primary, borderRadius: 7,
    paddingHorizontal: 8, paddingVertical: 4,
  },
  wonText: { fontSize: 10, color: '#000', fontWeight: '900', letterSpacing: 0.5 },
  lostBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: Colors.errorDim, borderRadius: 7,
    paddingHorizontal: 8, paddingVertical: 4,
    borderWidth: 1, borderColor: 'rgba(255,59,48,0.35)',
  },
  lostText: { fontSize: 10, color: Colors.error, fontWeight: '800', letterSpacing: 0.5 },
  pushBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: Colors.pushDim, borderRadius: 7,
    borderWidth: 1, borderColor: 'rgba(10,132,255,0.35)',
    paddingHorizontal: 8, paddingVertical: 4,
  },
  pushText: { fontSize: 10, color: Colors.push, fontWeight: '800', letterSpacing: 0.5 },
  dnpBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: Colors.dnpDim, borderRadius: 7,
    borderWidth: 1, borderColor: 'rgba(255,149,0,0.35)',
    paddingHorizontal: 8, paddingVertical: 4,
  },
  dnpText: { fontSize: 10, color: Colors.dnp, fontWeight: '800', letterSpacing: 0.5 },
  pickRow: { flexDirection: 'row', alignItems: 'center', gap: 6, flexWrap: 'wrap' },
  recPill: { paddingHorizontal: 7, paddingVertical: 2, borderRadius: 6 },
  recPillText: { fontSize: 10, fontWeight: '900', letterSpacing: 0.8 },
  pickDetail: { fontSize: 11, color: Colors.textSecondary, fontWeight: '500' },
  coinFlipBadge: { backgroundColor: Colors.cardSecondary, paddingHorizontal: 5, paddingVertical: 2, borderRadius: 5 },
  coinFlipText: { fontSize: 9, fontWeight: '800', color: Colors.textTertiary },
  confBadge: {
    paddingHorizontal: 5,
    paddingVertical: 2,
    borderRadius: 5,
    borderWidth: 1,
    backgroundColor: 'transparent',
  },
  confBadgeText: { fontSize: 9, fontWeight: '800', letterSpacing: 0.3 },

  trackBarOuter: {
    height: 4,
    backgroundColor: Colors.cardSecondary,
    borderRadius: 2,
    overflow: 'hidden',
    position: 'relative',
    marginTop: 2,
  },
  trackBarFill: {
    position: 'absolute',
    left: 0,
    top: 0,
    height: '100%' as unknown as number,
    borderRadius: 2,
  },
  trackBarMarker: {
    position: 'absolute',
    left: '50%' as unknown as number,
    top: 0,
    width: 1,
    height: '100%' as unknown as number,
    backgroundColor: 'rgba(255,255,255,0.55)',
    transform: [{ translateX: -0.5 }],
  },

  matchCtxBlock: {
    marginTop: 1,
    paddingTop: 3,
    borderTopWidth: 1,
    borderTopColor: Colors.borderSubtle,
  },
  paceWarningBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 6,
    paddingHorizontal: 8,
    paddingVertical: 6,
    borderRadius: 8,
    backgroundColor: Colors.dnpDim,
    borderWidth: 1,
    borderColor: 'rgba(255,149,0,0.35)',
  },
  paceWarningText: {
    flex: 1,
    fontSize: 11,
    fontWeight: '700',
    color: Colors.dnp,
    letterSpacing: 0.1,
  },
  matchCtxLine: {
    fontSize: 10,
    color: Colors.textTertiary,
    fontWeight: '600',
    letterSpacing: 0.1,
  },

  tapHint: {
    flexDirection: 'row', alignItems: 'center', gap: 3,
    paddingTop: 4, borderTopWidth: 1, borderTopColor: Colors.borderSubtle,
  },
  cardFooterWeb: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    marginTop: 6,
  },
  tapHintText: { fontSize: 9, color: Colors.primary, fontWeight: '600', letterSpacing: 0.3 },
});
