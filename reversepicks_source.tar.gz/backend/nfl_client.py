"""
BallDontLie NFL API client with rate-limiting and MongoDB caching.
Base URL: https://api.balldontlie.io/nfl/v1
Elite tier: 600 req/min.

NFL stat fields per game row:
  passing: passing_completions, passing_attempts, passing_yards, passing_touchdowns, passing_interceptions, qb_rating, sacks
  rushing: rushing_attempts, rushing_yards, rushing_touchdowns
  receiving: receptions, receiving_yards, receiving_touchdowns, targets
"""
import asyncio
import time
import os
import logging
from datetime import datetime, timezone
from typing import Optional

import httpx
from config import db

log = logging.getLogger("nfl_client")

NFL_API_BASE = "https://api.balldontlie.io/nfl/v1"
NFL_API_KEY  = os.environ.get("MLB_BDL_API_KEY", "")

_rate_sem = asyncio.Semaphore(2)   # shared BDL key — keep burst low
_last_req_time: float = 0.0
_MIN_INTERVAL = 0.25               # max ~4 req/s from this client

CACHE_TTL = {
    "teams":         7 * 86400,
    "player":        2 * 3600,
    "player_search": 4 * 3600,
    "stats":         2 * 3600,
}

CURRENT_NFL_SEASON = 2025


async def _get(path: str, params: dict = None) -> dict:
    global _last_req_time
    headers = {"Authorization": NFL_API_KEY}
    url = f"{NFL_API_BASE}{path}"

    async with _rate_sem:
        elapsed = time.monotonic() - _last_req_time
        if elapsed < _MIN_INTERVAL:
            await asyncio.sleep(_MIN_INTERVAL - elapsed)
        try:
            async with httpx.AsyncClient(timeout=20) as c:
                resp = await c.get(url, headers=headers, params=params or {})
        except Exception as e:
            raise RuntimeError(f"NFL API network error: {e}")
        finally:
            _last_req_time = time.monotonic()

        if resp.status_code != 429:
            if resp.status_code >= 400:
                raise RuntimeError(f"NFL API error {resp.status_code}: {resp.text[:200]}")
            return resp.json()

        retry_after = min(int(resp.headers.get("retry-after", "5")), 10)

    log.warning(f"[NFL CLIENT] 429 on {path} — waiting {retry_after}s")
    await asyncio.sleep(retry_after)

    async with _rate_sem:
        elapsed = time.monotonic() - _last_req_time
        if elapsed < _MIN_INTERVAL:
            await asyncio.sleep(_MIN_INTERVAL - elapsed)
        try:
            async with httpx.AsyncClient(timeout=20) as c:
                resp = await c.get(url, headers=headers, params=params or {})
        except Exception as e:
            raise RuntimeError(f"NFL API network error on retry: {e}")
        finally:
            _last_req_time = time.monotonic()

        if resp.status_code >= 400:
            raise RuntimeError(f"NFL API error {resp.status_code}: {resp.text[:200]}")
        return resp.json()


def _cache_fresh(doc: Optional[dict], ttl_seconds: int) -> bool:
    if not doc:
        return False
    ts = doc.get("ts", "")
    if not ts:
        return False
    try:
        age = (datetime.now(timezone.utc) -
               datetime.fromisoformat(str(ts)).replace(tzinfo=timezone.utc)).total_seconds()
        return age < ttl_seconds
    except Exception:
        return False


async def _cache_get(key: str) -> Optional[dict]:
    try:
        return await db.nfl_cache.find_one({"key": key}, {"_id": 0})
    except Exception:
        return None


async def _cache_set(key: str, data) -> None:
    try:
        await db.nfl_cache.update_one(
            {"key": key},
            {"$set": {"key": key, "data": data, "ts": datetime.now(timezone.utc).isoformat()}},
            upsert=True,
        )
    except Exception:
        pass


async def search_players(query: str, limit: int = 15) -> list:
    # search2: prefix busts stale caches poisoned by old-key 429 storms
    cache_key = f"search3:{query.lower()}"
    cached = await _cache_get(cache_key)
    if _cache_fresh(cached, CACHE_TTL["player_search"]):
        return cached["data"][:limit]

    results = []
    cursor = None
    for _ in range(3):
        params = {"search": query, "per_page": 25}
        if cursor:
            params["cursor"] = cursor
        try:
            data = await _get("/players", params)
        except Exception as e:
            log.warning(f"[NFL SEARCH] {e}")
            break
        rows = data.get("data", [])
        # Synthesise full_name for NFL (BDL returns first_name + last_name only)
        for p in rows:
            if "full_name" not in p:
                p["full_name"] = f"{p.get('first_name','')} {p.get('last_name','')}".strip()
        results.extend(rows)
        meta = data.get("meta", {})
        cursor = meta.get("next_cursor")
        if not cursor or len(results) >= limit:
            break

    # BDL search only matches single name tokens — fall back to last name
    if not results and " " in query:
        last_name = query.rsplit(" ", 1)[-1]
        try:
            data = await _get("/players", {"search": last_name, "per_page": 25})
        except Exception as e:
            log.warning(f"[NFL SEARCH fallback] {e}")
        else:
            rows = data.get("data", [])
            for p in rows:
                if "full_name" not in p:
                    p["full_name"] = f"{p.get('first_name','')} {p.get('last_name','')}".strip()
            # Sort by how many original query tokens appear in the player name
            q_tokens = query.lower().split()
            rows.sort(key=lambda p: sum(1 for t in q_tokens if t in p.get("full_name","").lower()), reverse=True)
            results = rows

    # Only cache non-empty results — transient 429 must not poison cache
    if results:
        await _cache_set(cache_key, results[:limit])
    return results[:limit]


async def get_player(player_id: int) -> Optional[dict]:
    cache_key = f"player:{player_id}"
    cached = await _cache_get(cache_key)
    if _cache_fresh(cached, CACHE_TTL["player"]):
        return cached["data"]
    try:
        data = await _get(f"/players/{player_id}")
        player = data.get("data", {})
        await _cache_set(cache_key, player)
        return player
    except Exception as e:
        log.warning(f"[NFL PLAYER] {e}")
        return None


async def get_teams() -> list:
    cache_key = "teams:all"
    cached = await _cache_get(cache_key)
    if _cache_fresh(cached, CACHE_TTL["teams"]):
        return cached["data"]
    try:
        data = await _get("/teams", {"per_page": 100})
        teams = data.get("data", [])
        await _cache_set(cache_key, teams)
        return teams
    except Exception as e:
        log.warning(f"[NFL TEAMS] {e}")
        return []


def _transform_nfl_log(row: dict) -> dict:
    """Normalise a raw BDL NFL /stats row to a unified schema."""
    game = row.get("game") or {}
    date_str = (game.get("date") or "")[:10]
    home_team    = game.get("home_team") or {}
    visitor_team = game.get("visitor_team") or {}
    home_team_id   = home_team.get("id")
    player_team_id = (row.get("team") or {}).get("id")
    is_home = player_team_id == home_team_id
    venue   = "home" if is_home else "away"

    # Opponent abbreviation / name
    opp_team = visitor_team if is_home else home_team
    opp_abbr = opp_team.get("abbreviation") or opp_team.get("name") or None

    # W/L from game scores
    home_sc = game.get("home_team_score")
    vis_sc  = game.get("visitor_team_score")
    won = None
    if home_sc is not None and vis_sc is not None:
        won = (home_sc > vis_sc) if is_home else (vis_sc > home_sc)

    pc   = (row.get("passing_completions") or 0)
    pa   = (row.get("passing_attempts") or 0)
    py   = (row.get("passing_yards") or 0)
    ptd  = (row.get("passing_touchdowns") or 0)
    pint = (row.get("passing_interceptions") or 0)
    sack = (row.get("sacks") or 0)
    qbr  = (row.get("qb_rating") or 0.0)
    ratt = (row.get("rushing_attempts") or 0)
    ry   = (row.get("rushing_yards") or 0)
    rtd  = (row.get("rushing_touchdowns") or 0)
    rec  = (row.get("receptions") or 0)
    recy = (row.get("receiving_yards") or 0)
    retd = (row.get("receiving_touchdowns") or 0)
    tgt  = (row.get("targets") or 0)
    lng_rush = (row.get("long_rushing") or 0)
    lng_recv = (row.get("long_reception") or 0)

    # DraftKings NFL fantasy: pass_yd/25 + pass_td*4 - int*1 + rush_yd/10 + rush_td*6 + rec*1 + recv_yd/10 + recv_td*6 - fum*2
    fantasy = (py / 25.0) + (ptd * 4) - (pint * 1) + (ry / 10.0) + (rtd * 6) + (rec * 1.0) + (recy / 10.0) + (retd * 6)

    return {
        "date":                date_str,
        "game_id":             game.get("id"),
        "venue":               venue,
        "opponent":            opp_abbr,
        "won":                 won,
        "week":                game.get("week"),
        "season":              game.get("season"),
        # Passing
        "passing_completions": pc,
        "passing_attempts":    pa,
        "passing_yards":       py,
        "passing_tds":         ptd,
        "interceptions":       pint,
        "sacks":               sack,
        "qb_rating":           qbr,
        "completion_pct":      round(pc / pa, 3) if pa > 0 else 0.0,
        # Rushing
        "carries":             ratt,
        "rushing_yards":       ry,
        "rushing_tds":         rtd,
        "long_rushing":        lng_rush,
        # Receiving
        "receptions":          rec,
        "receiving_yards":     recy,
        "receiving_tds":       retd,
        "targets":             tgt,
        "long_reception":      lng_recv,
        # Combos
        "passing_rushing_yards": py + ry,
        "anytime_td":          1 if (ptd + rtd + retd) > 0 else 0,
        "fantasy_pts":         round(fantasy, 1),
        "_source": "bdl",
    }


async def get_next_match(player_id: int) -> dict:
    """Find the next scheduled game for a given NFL player."""
    player = await get_player(player_id)
    if not player:
        return {"found": False}

    team = player.get("team") or {}
    team_id = team.get("id")
    if not team_id:
        return {"found": False}

    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    try:
        data = await _get("/games", {
            "team_ids[]": team_id,
            "seasons[]":  CURRENT_NFL_SEASON,
            "per_page":   100,
        })
        games = data.get("data", [])
    except Exception as e:
        log.warning(f"[NFL NEXT MATCH] {e}")
        return {"found": False}

    future = [
        g for g in games
        if (g.get("date") or "")[:10] >= today
        and g.get("status") not in ("Final", "completed", "closed", "complete")
    ]
    future.sort(key=lambda g: g.get("date", ""))

    if not future:
        return {"found": False}

    ng = future[0]
    home_team = ng.get("home_team") or {}
    away_team = ng.get("visitor_team") or {}
    is_home   = (home_team.get("id") == team_id)
    opp       = away_team if is_home else home_team

    return {
        "found":    True,
        "gameId":   ng.get("id"),
        "date":     (ng.get("date") or "")[:10],
        "venue":    "home" if is_home else "away",
        "opponent": {
            "id":           opp.get("id"),
            "name":         opp.get("full_name") or f"{opp.get('location', '')} {opp.get('name', '')}".strip(),
            "abbreviation": opp.get("abbreviation"),
        },
    }


async def get_player_game_logs(player_id: int, season: int = CURRENT_NFL_SEASON) -> list:
    """Fetch per-game stats for a player, newest-first."""
    cache_key = f"stats:{player_id}:{season}"
    cached = await _cache_get(cache_key)
    if _cache_fresh(cached, CACHE_TTL["stats"]):
        return cached["data"]

    all_rows = []
    cursor = None
    for _ in range(10):
        params = {"player_ids[]": player_id, "seasons[]": season, "per_page": 100}
        if cursor:
            params["cursor"] = cursor
        try:
            data = await _get("/stats", params)
        except Exception as e:
            log.warning(f"[NFL STATS] player={player_id}: {e}")
            break
        all_rows.extend(data.get("data", []))
        meta = data.get("meta", {})
        cursor = meta.get("next_cursor")
        if not cursor:
            break

    logs = [_transform_nfl_log(r) for r in all_rows]
    logs.sort(key=lambda x: x.get("date", ""), reverse=True)
    if logs:
        await _cache_set(cache_key, logs)
    return logs
